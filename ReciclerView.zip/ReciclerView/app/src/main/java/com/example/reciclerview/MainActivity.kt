package com.example.reciclerview

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    lateinit var btContato: Button
    lateinit var btLocal: Button
    lateinit var btSite: Button
    lateinit var btNovaTela: Button

    lateinit var recyclerView: RecyclerView
    lateinit var adapter: MyAdapter

    class MyAdapter {

    }

    lateinit var items: List<MyItem>

    enum class MyItem {

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializa os botões
        btContato = findViewById(R.id.btContato)
        btLocal = findViewById(R.id.btLocal)
        btSite = findViewById(R.id.btSite)
        btNovaTela = findViewById(R.id.btNovaTela)

        // Configurar o RecyclerView
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Criar uma lista de elementos
        items = listOf(
            MyItem("Elemento 1"),
            MyItem("Elemento 2"),
            // Agrega más elementos según sea necesario
        )

        // Inicializar e configurar o adaptador
        adapter = MyAdapter(items)
        recyclerView.adapter = adapter
    }
}